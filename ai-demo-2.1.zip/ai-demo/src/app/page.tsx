// ai-demo/src/app/page.tsx
import Welcome from "@/components/Welcome";
export default function Home() {
  return (
    <>
      <Welcome />
    </>
  );
}
